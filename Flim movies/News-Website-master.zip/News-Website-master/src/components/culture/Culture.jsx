import React from "react"

const Culture = () => {
  return (
    <>
      <section className='culture'>
        <div className='container paddingTB'>
          <h1>Culture Sections</h1>
        </div>
      </section>
    </>
  )
}

export default Culture
